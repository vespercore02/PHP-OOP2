<?php 

namespace Models;

use PDO;
use Core\Model;

class Employee extends Model
{
    public function getAllEmp()
    {
        $sql = "SELECT * FROM emp_info ";
        $stmt = $this->getDB1()->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);

    }
}

?>