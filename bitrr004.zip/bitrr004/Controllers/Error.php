<?php 

namespace Controllers;

use Core\Controller;

class Error extends Controller {

    public function __construct()
    {
        
    }

    public function index()
    {
        $this->view('404');
    }
}


?>