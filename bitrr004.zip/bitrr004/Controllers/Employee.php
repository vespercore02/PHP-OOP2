<?php 

namespace Controllers;

use Core\Controller;

class Employee extends Controller
{
    public function __construct()
    {
        $this->empModel = $this->model('Employee');
    }

    public function index()
    {
        # code...

        $data = $this->empModel->getAllEmp();

        $this->view('Employee/index', $data);
    }

    public function error()
    {
        $this->view('404');
    }
}

?>