<?php 

namespace Controllers;

use Core\Controller;

class Home extends Controller
{
    public function __construct()
    {
        //echo "Home";
    }

    public function index()
    {
        $this->view('Home/index');
    }

    public function page($id)
    {
        echo "About";
    }

    public function about()
    {
        echo "About";
    }

    public function classNotFound()
    {
        echo "Class Not Found";
    }

    public function error()
    {
        $this->view('404');
    }
}


?>