<?php 

include_once 'autoload.php';

//require_once '..\Core\Router.php';

$init = new Core\Router();



?>