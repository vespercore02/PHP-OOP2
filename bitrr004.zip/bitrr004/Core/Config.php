<?php 

namespace Core;

class Config
{
    /**
     * Database host
     * @var string
     */
    const DB_HOST1 = 'localhost';

    /**
     * Database name
     * @var string
     */
    const DB_NAME1 = 'pet_employees';

    /**
     * Database user
     * @var string
     */
    const DB_USER1 = 'root';

    /**
     * Database password
     * @var string
     */
    const DB_PASSWORD1 = '';

    const DB_CHARSET1 = 'utf8mb4';
}


?>