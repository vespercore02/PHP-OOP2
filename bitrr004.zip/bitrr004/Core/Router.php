<?php 

namespace Core;

class Router 
{
    protected $Controller = 'Home';
    protected $Method = "index";
    protected $params = [];

    public function __construct()
    {
        $url = $this->run();
        
        if (!empty($url[0])) {
            if(file_exists('../Controllers/' . ucwords($url[0]). '.php')){
                $this->Controller = ucwords($url[0]);
                unset($url[0]);
            }else {
                $this->Controller = "Error";
            }
        }

        require_once '../Controllers/'. $this->Controller . '.php';
        $namespace_controller = 'Controllers\\'. $this->Controller;

        $this->Controller = new $namespace_controller;

        if(isset($url[1])){
            
            if(method_exists($this->Controller, $url[1])){
                $this->Method = $url[1];
                unset($url[1]);
            }else {
                $this->Method = "Error";
            }
        }
        
        
        $this->params = $url ? array_values($url) : [];

        call_user_func_array([$this->Controller, $this->Method], $this->params);
    }
    
    public function run()
    {
        $url = rtrim($_SERVER['QUERY_STRING'], '/');
        $url = filter_var($url, FILTER_SANITIZE_URL);
        $url = explode('/', $url);

        return $url;
    }

}



?>