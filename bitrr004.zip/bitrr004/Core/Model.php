<?php 

namespace Core;

use PDO;
use FFI\Exception;

abstract class Model
{
    protected static function getDb1()
    {
        try {
            //code...
            $dsn = "mysql:host=".Config::DB_HOST1.";dbname=".Config::DB_NAME1.";charset=".Config::DB_CHARSET1;
            $pdo = new \PDO($dsn, Config::DB_USER1, Config::DB_PASSWORD1);
            
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            return $pdo;

        } catch (Exception $e) {
            //throw $th;
            echo "Connection Failed: ".$e->getMessage();
        }
    }
}

?>