<?php 

namespace Core;

class Controller
{
    public function model($model) {

        require_once '../Models/' . $model . '.php';

        $namespace_model = "Models\\".$model;
        
        return new $namespace_model();
    }

    public function view($view, $data = []) {
        if (file_exists('../Views/' . $view . '.php')) {
            require_once '../Views/' . $view . '.php';
        } else {
            die("View does not exists.");
        }
    }
}

?>