<?php 

require_once "../Views/Layouts/head.php";


require_once "../Views/Layouts/nav.php";
?>