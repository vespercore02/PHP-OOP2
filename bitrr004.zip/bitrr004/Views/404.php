  
<?php 

require_once "../Views/base.php";

?>


<div class="container">
    <div class="row justify-content-md-center">
    
        <div class="col-8">

            <div class="my-3 p-3 bg-white rounded shadow-lg">
                
                
                <h1>Page not found</h1>
                <p>Sorry, that page doesn't exist.</p>
                
            </div>
        </div>
    
    </div>
</div>