  
<?php 

require_once "../Views/base.php";

?>

<div class="container">
    <div class="row justify-content-md-center">
    
        <div class="col-8">

            <div class="my-3 p-3 bg-white rounded shadow-lg">
                
                
                <h3>Welcome</h3>

                
                
            </div>
        </div>
    
    </div>
</div>